$(document).ready(function() {
    $( 'button' ).click( function() {
        alert('To learn more about the Raspberry Pi, pick up a copy of Linux Voice');
    });
});
